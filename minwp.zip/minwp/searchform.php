<div class="searchform">
	<form method="get" action="<?php echo home_url( '/' ); ?>">
		<input type="search" name="s" id="s" placeholder="Search for ..." />
		<button class="addon btn  btn-sm smooth" type="submit" ="searchsubmit" value="<?php esc_attr_e('Go', 'minwp'); ?>"><?php esc_attr_e('Go', 'minwp'); ?></button>
	</form>
</div>
